import Banner from './Banner'

function App() {
  return (
    <>
      <Banner />
    </>
  )
}

export default App
