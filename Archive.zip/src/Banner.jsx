
function Banner() {
  return (
    <div className="text-xl text-green-400 text-center p-4 bg-black">We are there to learn React from tapaScript</div>
  )
}

export default Banner